#!/usr/bin/env bash
# r3. One-shot detached job: preflight (controls, fixtures, r2-vs-r3 equivalence) -> two-fixture smoke (all 4 mutants on both) -> gate -> full 36-fixture run -> gate.
# Writes only under $JOB. Records every stage durably in $JOB/STATUS.txt. Not a service; exits when done.
set -u
PKG="$(cd "$(dirname "$0")/.." && pwd)"          # extracted package root
JOB="$1"                                          # job directory (must not exist)
PY="${PYTHON:-$HOME/SCYTHE/.venv/bin/python}"      # existing interpreter; nothing is installed
[ -e "$JOB" ] && { echo "job dir exists: $JOB" >&2; exit 2; }
mkdir -p "$JOB/logs" || exit 2
st() { echo "$(date -Is) $*" >> "$JOB/STATUS.txt"; sync "$JOB/STATUS.txt" 2>/dev/null; }
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
cd "$PKG" || exit 2
st "START job=$JOB pkg=$PKG pid=$$"
{ echo "uname: $(uname -a)"; echo "python: $($PY -c 'import sys,numpy;print(sys.version.replace(chr(10)," "),"numpy",numpy.__version__)')"
  echo "threads: OPENBLAS=$OPENBLAS_NUM_THREADS OMP=$OMP_NUM_THREADS MKL=$MKL_NUM_THREADS NUMEXPR=$NUMEXPR_NUM_THREADS"
  echo "nproc: $(nproc)"; df -h "$JOB" | tail -1; } > "$JOB/env.txt" 2>&1
sha256sum -c SHA256SUMS > "$JOB/logs/package_verify.txt" 2>&1 || { st "FAILED package hash verification"; exit 10; }
st "OK package verified"
$PY -m unittest test_rf_metamorphic_controls > "$JOB/logs/controls.txt" 2>&1 || { st "FAILED bounded controls"; exit 11; }
st "OK 12 bounded controls ($(grep -E '^Ran' "$JOB/logs/controls.txt"))"
$PY fixtures/generate_holdout.py --spec fixtures/synth_521_holdout_frozen.json --outdir "$JOB/holdout" > "$JOB/logs/fixtures_generate.txt" 2>&1 || { st "FAILED fixture generation"; exit 12; }
( cd "$JOB/holdout" && sha256sum -c "$PKG/fixtures/fixture_hashes.sha256" ) > "$JOB/logs/fixtures_verify.txt" 2>&1 || { st "FAILED fixture hash verification"; exit 13; }
st "OK fixtures regenerated, 36/36 hashes verified"
H="$PKG/fixtures/fixture_hashes.sha256"
$PY tools/rf_metamorphic_r3_equivalence_check.py --holdout "$JOB/holdout" --hashes "$H" --out "$JOB/equivalence_r2_vs_r3.json" > "$JOB/logs/equivalence.log" 2>&1
rc=$?; echo "r2-vs-r3 equivalence exit=$rc" >> "$JOB/exit_codes.txt"; st "r2-vs-r3 equivalence exit=$rc: $(tail -1 "$JOB/logs/equivalence.log")"
[ $rc -eq 0 ] || { st "FAILED r2-vs-r3 equivalence; nothing further run"; exit 16; }
$PY tools/rf_metamorphic_harness.py --holdout "$JOB/holdout" --hashes "$H" --results-dir "$JOB/results_smoke" --limit 2 --mutant-fixtures 2 > "$JOB/logs/smoke.log" 2>&1
rc=$?; echo "smoke exit=$rc" >> "$JOB/exit_codes.txt"; st "smoke harness exit=$rc"
[ $rc -eq 0 ] || { st "FAILED smoke run"; exit 14; }
$PY job/gate_results.py "$JOB/results_smoke" 2 2 > "$JOB/logs/smoke_gate.txt" 2>&1
rc=$?; echo "smoke gate exit=$rc" >> "$JOB/exit_codes.txt"; st "smoke gate exit=$rc: $(head -1 "$JOB/logs/smoke_gate.txt")"
[ $rc -eq 0 ] || { st "FAILED smoke gate; full run NOT started"; exit 15; }
st "BEGIN full run (36 fixtures, mutants on first 6)"
$PY tools/rf_metamorphic_harness.py --holdout "$JOB/holdout" --hashes "$H" --results-dir "$JOB/results_full" --mutant-fixtures 6 > "$JOB/logs/full.log" 2>&1
rc=$?; echo "full exit=$rc" >> "$JOB/exit_codes.txt"; st "full harness exit=$rc"
$PY job/gate_results.py "$JOB/results_full" 36 6 > "$JOB/logs/full_gate.txt" 2>&1
grc=$?; echo "full gate exit=$grc" >> "$JOB/exit_codes.txt"; st "full gate exit=$grc: $(head -1 "$JOB/logs/full_gate.txt")"
( cd "$JOB" && find results_smoke results_full logs STATUS.txt exit_codes.txt env.txt -type f 2>/dev/null | sort | xargs sha256sum > JOB_SHA256SUMS )
st "DONE harness_rc=$rc gate_rc=$grc (outputs retained on this host until independently verified)"
exit $(( rc != 0 || grc != 0 ))
