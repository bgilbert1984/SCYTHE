#!/usr/bin/env python3
"""Acceptance gate for a metamorphic r2 results directory (smoke or full). Reads records only.

Usage: gate_results.py RESULTS_DIR EXPECTED_FIXTURES EXPECTED_MUTANT_FIXTURES
Exit 0 only if every check passes; every failure is printed.  A RESOURCE_LIMIT_REFUSAL is an
accepted classification for a mutant but is never counted as detection.
"""
import hashlib, json, os, sys
rd, nfix, nmut = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
H = None
here = os.path.dirname(os.path.abspath(__file__))
import importlib.util
spec = importlib.util.spec_from_file_location("h", os.path.join(here, "..", "tools", "rf_metamorphic_harness.py"))
H = importlib.util.module_from_spec(spec); spec.loader.exec_module(H)
fails = []
def need(cond, msg):
    if not cond: fails.append(msg)
need(not os.path.exists(os.path.join(rd, "STOPPED.json")), "STOPPED.json present (identity failure)")
ident = json.load(open(os.path.join(rd, "identity.json")))
need(ident["verdict"] == "IDENTITY_AND_NAMESPACE_VERIFIED", f"identity verdict {ident['verdict']}")
need(len(ident["per_fixture"]) == nfix and all(ident["per_fixture"].values()), "identity not equal on every fixture")
ok, bad, missing = H.verify_manifest(rd)
need(not bad and not missing, f"manifest: bad={bad} missing={missing}")
A = sorted(f for f in os.listdir(os.path.join(rd, "phaseA")) if f.endswith(".json"))
B = sorted(f for f in os.listdir(os.path.join(rd, "phaseB")) if f.endswith(".json"))
need(len(A) == nfix, f"phaseA records {len(A)} != {nfix}")
need(len(B) == 4 * nmut, f"phaseB records {len(B)} != {4*nmut}")
need(not [f for f in os.listdir(os.path.join(rd, "phaseA")) + os.listdir(os.path.join(rd, "phaseB")) if f.endswith(".tmp")], "stray .tmp file")
mset = {}
for f in B:
    e = json.load(open(os.path.join(rd, "phaseB", f)))
    need(e.get("status") in ("COMPLETED", "RESOURCE_LIMIT_REFUSAL"), f"{f}: status {e.get('status')}")
    if e.get("status") == "RESOURCE_LIMIT_REFUSAL":
        need(not e.get("relations"), f"{f}: refusal carries relation credit")
    mset[e["mutant"]] = mset.get(e["mutant"], 0) + 1
need(sorted(mset) == sorted(H.MUTATIONS) and set(mset.values()) == {nmut}, f"mutant coverage {mset}")
s = H.summarize.__wrapped__(rd) if hasattr(H.summarize, "__wrapped__") else None
# summary must agree with the individual records
summ = json.load(open(os.path.join(rd, "summary.json")))
counts = {}
for f in A:
    for k, d in json.load(open(os.path.join(rd, "phaseA", f)))["relations"].items():
        counts.setdefault(k, {}).setdefault(d["verdict"], 0); counts[k][d["verdict"]] += 1
need(counts == summ["relation_summary"], "summary relation_summary disagrees with Phase A records")
need(all(sum(v.values()) == nfix for v in summ["relation_summary"].values()), "relation totals != fixtures")
print("GATE", "PASS" if not fails else "FAIL")
for m in fails: print("  -", m)
sys.exit(0 if not fails else 1)
