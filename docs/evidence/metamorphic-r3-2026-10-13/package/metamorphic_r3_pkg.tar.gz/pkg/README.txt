Metamorphic harness r3 -- one-shot research job package. Synthetic fixtures and research code only.
No real IQ, no SDR contact, no services installed, nothing written outside the job directory.
Source: commit 3037194 (research/metamorphic-rf-harness); production modules byte-identical to origin/main.
r3 supersedes r2 (interrupted: repeated whole-spectrum median in the one-repeat worst-case check).
Fixtures are regenerated deterministically (generate_holdout.py + frozen spec) and verified against fixture_hashes.sha256.
Stages: package verify -> 17 bounded controls -> fixtures 36/36 -> r2-vs-r3 equivalence -> smoke(2 fixtures, 4 mutants) -> gate
        -> Phase A (36) -> Phase B (first 6 fixtures x 4 mutants) -> final gate.
Run:  job/run_job.sh <NEW_JOB_DIR>      (detach with setsid nohup; it refuses an existing directory)
