#!/usr/bin/env python3
"""Generate holdout fixtures from frozen spec.

Usage:
    python3 generate_holdout.py [--spec PATH] [--outdir PATH]

Regenerates the 36 holdout fixtures deterministically from
synth_521_holdout_frozen.json. Verifies against fixture_hashes.sha256
if present in the output directory's parent review package.
"""

import json
import os
import argparse
import hashlib

import numpy as np


def gen_windows(seed, tones, sr, n_win, sigma=1.0):
    rng = np.random.default_rng(seed)
    t = np.arange(n_win) / sr
    windows = []
    for _ in range(8):
        noise = (rng.standard_normal(n_win) + 1j * rng.standard_normal(n_win)).astype(np.complex64) * sigma
        sig = noise.copy()
        for freq, amp, phase in tones:
            tone = amp * np.exp(2j * np.pi * freq * t + 1j * phase)
            sig = sig + tone.astype(np.complex64)
        windows.append(sig)
    return np.stack(windows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--spec', default=os.path.expanduser('~/workspace/synth_521_holdout_frozen.json'))
    ap.add_argument('--outdir', default=os.path.expanduser('~/workspace/synth521_holdout'))
    args = ap.parse_args()

    with open(args.spec) as f:
        frozen = json.load(f)

    sr = frozen["sample_rate_hz"]
    n_win = frozen["window_samples"]
    bin_hz = frozen["bin_spacing_hz"]
    os.makedirs(args.outdir, exist_ok=True)

    index = {"family_a": [], "family_b": []}

    # Family A
    seed = frozen["seeds"]["family_A_start"]
    fa = frozen["families"]["family_A_isolated"]
    for sign in fa["signs"]:
        for frac in fa["fractional_offsets_bins"]:
            for amp in fa["levels"]:
                freq = sign * (fa["base_freq_hz"] + frac * bin_hz)
                name = f"HA_s{'+' if sign > 0 else '-'}f{frac:.2f}a{amp}"
                arr = gen_windows(seed, [(freq, amp, 0.0)], sr, n_win)
                np.save(os.path.join(args.outdir, name + ".npy"), arr)
                index["family_a"].append(
                    {"name": name, "freq": freq, "amp": amp, "frac": frac, "seed": seed})
                seed += 1
                del arr

    # Family B
    seed = frozen["seeds"]["family_B_start"]
    fb = frozen["families"]["family_B_twotone"]
    for sep in fb["separations_bins"]:
        for rel_db in fb["relative_strength_db"]:
            for phase in fb["phase_offsets_rad"]:
                for frac in fb["fractional_offsets_bins"]:
                    strong_freq = fb["strong_freq_hz"] + frac * bin_hz
                    weak_freq = strong_freq + sep * bin_hz
                    strong_amp = 0.1
                    weak_amp = strong_amp * 10 ** (rel_db / 20)
                    name = f"HB_sep{sep}r{rel_db}p{phase:.2f}f{frac:.2f}"
                    arr = gen_windows(seed, [(strong_freq, strong_amp, 0.0),
                                             (weak_freq, weak_amp, phase)], sr, n_win)
                    np.save(os.path.join(args.outdir, name + ".npy"), arr)
                    index["family_b"].append({
                        "name": name, "strong_freq": strong_freq,
                        "weak_freq": weak_freq, "sep_bins": sep,
                        "rel_db": rel_db, "frac": frac, "seed": seed})
                    seed += 1
                    del arr

    n_total = len(index["family_a"]) + len(index["family_b"])
    print(f"Generated {n_total} fixtures in {args.outdir}")

    idx_path = os.path.join(os.path.dirname(args.outdir.rstrip('/')), 'synth521_holdout_index.json')
    # Also write beside outdir for convenience
    with open(os.path.join(args.outdir, 'index.json'), 'w') as f:
        json.dump(index, f, indent=2)


if __name__ == '__main__':
    main()
