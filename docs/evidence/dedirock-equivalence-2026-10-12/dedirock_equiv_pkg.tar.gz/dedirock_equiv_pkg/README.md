# Dedirock Equivalence Package: v2-Hann Detector

## Purpose
Establish runtime equivalence of seq-7.2-1-hann on dedirock using the same
36 hash-verified holdout fixtures and actual production retention. Isolates
runtime differences (Python/NumPy/FFT) before introducing real recordings.

## Contents
- `dedirock_equivalence.py` — Runner: records env versions, runs all 36 fixtures
  through production detect_candidates + production measure_persistence
- `dedirock_equivalence_pin.json` — Pinned code/fixture hashes, tolerances
- `synth_521_holdout_frozen.json` — Fixture spec (regenerate via generate_holdout.py)
- `synth521_holdout_index.json` — Fixture index with true frequencies
- `fixture_hashes.sha256` — Expected SHA256 of all 36 fixture .npy files
- `generate_holdout.py` — Deterministic fixture generator from frozen spec

## Run on dedirock
```bash
# 1. Ensure SCYTHE @ 68283192 (merge) or ef3c6f4a (publication commit)
cd ~/SCYTHE && git log --oneline -1  # should show 68283192 or later

# 2. Generate fixtures (or copy the 36 .npy files)
python3 generate_holdout.py --outdir /tmp/dedirock_holdout
sha256sum -c fixture_hashes.sha256  # verify in /tmp/dedirock_holdout

# 3. Run equivalence
python3 dedirock_equivalence.py \
  --scythe ~/SCYTHE \
  --holdout /tmp/dedirock_holdout \
  --index synth521_holdout_index.json \
  --out dedirock_equivalence_results.json
```

## Compare
Against `~/workspace/synth521_holdout_results.json` (v2_hann) and the
corrected production-retention evaluation:
- v2 expected: 20/20 in-tol, 0 unmatched persistent; 16/16 strong, 16/16 weak, 0 false
- Tolerances fixed at 1e-9 Hz/dB. Investigate any mismatch before changing.
