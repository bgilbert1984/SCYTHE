#!/usr/bin/env python3
"""Dedirock equivalence runner for v2-Hann detector.

Runs the 36 hash-verified holdout fixtures through the production
detect_candidates + production measure_persistence on this host,
recording environment versions and per-fixture results for comparison
against the reviewed results.

Usage:
    python3 dedirock_equivalence.py --scythe /path/to/SCYTHE --holdout /path/to/fixtures

Output: dedirock_equivalence_results.json with:
  - environment: python, numpy, fft backend versions
  - code_hash: sha256 of rf_spur_catalogue_sequencer.py
  - per-fixture: candidate counts, bins, frequencies, excess, retention decisions
"""

import argparse
import hashlib
import json
import os
import sys

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scythe', required=True, help='Path to SCYTHE repo checkout')
    ap.add_argument('--holdout', required=True, help='Path to holdout fixture .npy files')
    ap.add_argument('--index', required=True, help='Path to synth521_holdout_index.json')
    ap.add_argument('--out', default='dedirock_equivalence_results.json')
    args = ap.parse_args()

    sys.path.insert(0, args.scythe)
    from rf_spur_catalogue_sequencer import detect_candidates, SEQUENCER_REVISION
    from rf_spur_retention_estimator import measure_persistence

    # Environment versions
    env = {
        "python": sys.version,
        "numpy": np.__version__,
        "fft_backend": np.fft.__name__,
    }
    try:
        import numpy.fft as _npfft
        # pocketfft is the default backend; record if mkl/scipy overrides exist
        env["fft_pocketfft"] = True
    except Exception:
        pass

    # Code hash
    seq_path = os.path.join(args.scythe, 'rf_spur_catalogue_sequencer.py')
    with open(seq_path, 'rb') as f:
        code_hash = hashlib.sha256(f.read()).hexdigest()
    ret_path = os.path.join(args.scythe, 'rf_spur_retention_estimator.py')
    with open(ret_path, 'rb') as f:
        ret_hash = hashlib.sha256(f.read()).hexdigest()

    with open(args.index) as f:
        index = json.load(f)

    SR = 2048000
    TOL_HZ = 1.0

    def match_one_to_one(candidates, true_freqs):
        pairs = []
        for ti, tf in enumerate(true_freqs):
            for ci, c in enumerate(candidates):
                err = abs(c.baseband_hz - tf)
                if err < TOL_HZ:
                    pairs.append((err, ti, ci))
        pairs.sort()
        matched_tones = {}
        matched_cands = set()
        for err, ti, ci in pairs:
            if ti not in matched_tones and ci not in matched_cands:
                matched_tones[ti] = (ci, err)
                matched_cands.add(ci)
        unmatched = [ci for ci in range(len(candidates)) if ci not in matched_cands]
        return matched_tones, unmatched

    per_fixture = []
    for item in index["family_a"] + index["family_b"]:
        arr = np.load(os.path.join(args.holdout, item['name'] + '.npy'))
        windows = [arr[i] for i in range(8)]
        cands = detect_candidates(windows)

        # Fixture hash
        with open(os.path.join(args.holdout, item['name'] + '.npy'), 'rb') as f:
            fixture_hash = hashlib.sha256(f.read()).hexdigest()[:16]

        true_freqs = [item["freq"]] if "freq" in item else [item["strong_freq"], item["weak_freq"]]
        matched, unmatched = match_one_to_one(cands, true_freqs)

        candidates = []
        for ci, c in enumerate(cands):
            try:
                obs = measure_persistence(
                    tuning_id="dedirock-equiv",
                    windows=windows,
                    sample_rate_hz=SR,
                    feature_baseband_hz=c.baseband_hz,
                )
                qualifying = obs.qualifying()
                persistent = obs.persistent()
            except Exception as e:
                qualifying = -1
                persistent = False
            candidates.append({
                "peak_bin": c.peak_bin,
                "baseband_hz": c.baseband_hz,
                "excess_db": c.excess_db,
                "qualifying_repeats": qualifying,
                "persistent": persistent,
                "matched_tone": None,
            })

        for ti, (ci, err) in matched.items():
            candidates[ci]["matched_tone"] = ti
            candidates[ci]["match_error_hz"] = err

        per_fixture.append({
            "name": item["name"],
            "fixture_sha256_16": fixture_hash,
            "candidate_count": len(cands),
            "matched_tones": sorted(matched.keys()),
            "unmatched_count": len(unmatched),
            "candidates": candidates,
        })
        del arr

    result = {
        "environment": env,
        "code": {
            "sequencer_revision": SEQUENCER_REVISION,
            "sequencer_sha256": code_hash,
            "retention_sha256": ret_hash,
        },
        "tolerances": {"freq_hz": 1e-9, "match_hz": TOL_HZ},
        "per_fixture": per_fixture,
    }

    with open(args.out, 'w') as f:
        json.dump(result, f, indent=2)
    print(f"Wrote {args.out}: {len(per_fixture)} fixtures")
    print(f"Python {sys.version.split()[0]}, NumPy {np.__version__}, {SEQUENCER_REVISION}")


if __name__ == '__main__':
    main()
